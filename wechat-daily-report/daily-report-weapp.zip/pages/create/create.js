// create.js
Page({
  data: {
    currentDate: '',
    todayWork: '',
    tomorrowPlan: '',
    problems: '',
    remarks: ''
  },

  onLoad: function() {
    // 获取当前日期
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const weekday = weekdays[now.getDay()];
    
    this.setData({
      currentDate: `${year}-${month}-${day} ${weekday}`
    });
  },

  onTodayWorkInput: function(e) {
    this.setData({
      todayWork: e.detail.value
    });
  },

  onTomorrowPlanInput: function(e) {
    this.setData({
      tomorrowPlan: e.detail.value
    });
  },

  onProblemsInput: function(e) {
    this.setData({
      problems: e.detail.value
    });
  },

  onRemarksInput: function(e) {
    this.setData({
      remarks: e.detail.value
    });
  },

  submitForm: function(e) {
    const { todayWork, tomorrowPlan } = this.data;
    
    // 验证必填字段
    if (!todayWork.trim()) {
      wx.showToast({
        title: '请输入今日工作内容',
        icon: 'none'
      });
      return;
    }
    
    if (!tomorrowPlan.trim()) {
      wx.showToast({
        title: '请输入明日工作计划',
        icon: 'none'
      });
      return;
    }
    
    // 生成唯一ID
    const id = Date.now().toString();
    const reportData = {
      id: id,
      date: this.data.currentDate.split(' ')[0],
      weekday: this.data.currentDate.split(' ')[1],
      todayWork: this.data.todayWork,
      tomorrowPlan: this.data.tomorrowPlan,
      problems: this.data.problems,
      remarks: this.data.remarks,
      createTime: new Date().toISOString()
    };
    
    // 保存到本地存储
    try {
      let dailyData = wx.getStorageSync('dailyReports') || [];
      dailyData.push(reportData);
      wx.setStorageSync('dailyReports', dailyData);
      
      wx.showToast({
        title: '日报提交成功',
        icon: 'success'
      });
      
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (e) {
      console.error("保存日报失败", e);
      wx.showToast({
        title: '保存失败，请重试',
        icon: 'none'
      });
    }
  },

  cancelCreate: function() {
    wx.navigateBack();
  }
});