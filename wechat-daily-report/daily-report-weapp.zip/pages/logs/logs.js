// logs.js
Page({
  data: {
    dailyInfo: null
  },

  onLoad: function(options) {
    const id = options.id;
    this.loadDailyDetail(id);
  },

  loadDailyDetail: function(id) {
    try {
      const dailyData = wx.getStorageSync('dailyReports') || [];
      const dailyItem = dailyData.find(item => item.id === id);
      
      if (dailyItem) {
        this.setData({
          dailyInfo: dailyItem
        });
      }
    } catch (e) {
      console.error("读取日报详情失败", e);
    }
  },

  goBack: function() {
    wx.navigateBack();
  }
});