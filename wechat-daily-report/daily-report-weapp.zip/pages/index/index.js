// pages/index/index.js
Page({
  data: {
    dailyList: []
  },

  onLoad: function() {
    this.loadDailyList();
  },

  onShow: function() {
    this.loadDailyList(); // 每次进入页面都重新加载数据
  },

  loadDailyList: function() {
    // 从本地存储获取日报数据
    try {
      const dailyData = wx.getStorageSync('dailyReports') || [];
      this.setData({
        dailyList: dailyData.reverse() // 倒序显示，最新的在前面
      });
    } catch (e) {
      console.error("读取日报数据失败", e);
      this.setData({
        dailyList: []
      });
    }
  },

  createNew: function() {
    wx.navigateTo({
      url: '/pages/create/create'
    });
  },

  viewDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/logs/logs?id=${id}`
    });
  }
});